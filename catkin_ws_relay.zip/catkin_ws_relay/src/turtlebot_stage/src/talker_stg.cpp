#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"

ros::Publisher vel_pub;
ros::Subscriber scan_sub;

void laserCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
    ROS_INFO("Got laser scan data\n");
    unsigned int i, beam_count;
    double dir = 0.0, angle = scan->angle_min, sum = 0.0, weight = 0.0;
    beam_count = scan->ranges.size();
    for (i = 0; i < beam_count; i++)
    {
	if (fabs(angle) < 90.0)
        {
        weight = scan->range_max - scan->ranges[i];
        dir += angle * weight;
        angle += scan->angle_increment;
        sum += weight;
        }
    /*    if (fabs(scan->range_max - scan->ranges[i]) > 0.01)
            weight = 1.0;
        else
            weight = 0.0;*/
    }
    if (sum > 0.0001)
        dir /= -sum;
    else
        dir = 0.0;
    geometry_msgs::Twist cmd_vel;
    cmd_vel.linear.x = 1.0;
    cmd_vel.angular.z = dir;
    ROS_INFO("Angular = %f\n", cmd_vel.angular.z);
    vel_pub.publish(cmd_vel);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "controller");

    ros::NodeHandle n;

    vel_pub = n.advertise<geometry_msgs::Twist>("/robot_0/cmd_vel", 5);

    scan_sub = n.subscribe("/robot_0/base_scan", 5, laserCallback);

    ros::spin();

    return 0;
}
