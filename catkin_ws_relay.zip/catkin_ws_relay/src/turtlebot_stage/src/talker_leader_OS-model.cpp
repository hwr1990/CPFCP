#include "iostream"
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"

#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>

#include <turtlebot_stage/wayPoint.h>

using namespace std;

#define PI 3.1415926
#define Num_Agent 5
#define senseRange 4
#define delta_T 0.1
#define c1 0.2
#define c2 0.2
#define epsilon 0.1
#define r 4
#define h 0.2
#define a 5
#define b 5
#define d 3

int uID;

geometry_msgs::Twist cmd_vel;

ros::Publisher vel_pub_;
ros::Subscriber state_sub_;
ros::Subscriber nb1State_sub_;
ros::Subscriber nb2State_sub_;
ros::Subscriber nb3State_sub_;
ros::Subscriber nb4State_sub_;

ros::Subscriber wayPoint_sub_;
	
float* position_data;
float* velocity_data;
float goal_X,goal_Y;

void wayPointCb(const turtlebot_stage::wayPoint::ConstPtr& msg)
{
	goal_X = msg->x;
	goal_Y = msg->y;
}


void stateCb(const nav_msgs::Odometry::ConstPtr& msg)
{
/*
char filepath[100] = "/home/exbot/catkin_ws_relay/src/turtlebot_stage/src/state.txt";
//sprintf(filepath, "/home/exbot/catkin_ws_relay/src/turtlebot_stage/src/state.txt");
FILE *pFile=fopen(filepath,"a");
fprintf(pFile, "px:%f py:%f\n", msg->pose.pose.position.x,msg->pose.pose.position.x);
fclose(pFile);*/

    *(position_data + 2*0) = msg->pose.pose.position.x;
    *(position_data + 2*0+1) = msg->pose.pose.position.y;

	*(velocity_data + 2*0) = msg->twist.twist.linear.x;
	*(velocity_data + 2*0+1) = msg->twist.twist.linear.y;
}

void nb1StateCb(const nav_msgs::Odometry::ConstPtr& msg)
{
    *(position_data + 2*1) = msg->pose.pose.position.x;
    *(position_data + 2*1+1) = msg->pose.pose.position.y;

	*(velocity_data + 2*1) = msg->twist.twist.linear.x;
	*(velocity_data + 2*1+1) = msg->twist.twist.linear.y;
}

void nb2StateCb(const nav_msgs::Odometry::ConstPtr& msg)
{
    *(position_data + 2*2) = msg->pose.pose.position.x;
    *(position_data + 2*2+1) = msg->pose.pose.position.y;

	*(velocity_data + 2*2) = msg->twist.twist.linear.x;
	*(velocity_data + 2*2+1) = msg->twist.twist.linear.y;
}

void nb3StateCb(const nav_msgs::Odometry::ConstPtr& msg)
{
    *(position_data + 2*3) = msg->pose.pose.position.x;
    *(position_data + 2*3+1) = msg->pose.pose.position.y;

	*(velocity_data + 2*3) = msg->twist.twist.linear.x;
	*(velocity_data + 2*3+1) = msg->twist.twist.linear.y;
}

void nb4StateCb(const nav_msgs::Odometry::ConstPtr& msg)
{
    *(position_data + 2*4) = msg->pose.pose.position.x;
    *(position_data + 2*4+1) = msg->pose.pose.position.y;

	*(velocity_data + 2*4) = msg->twist.twist.linear.x;
	*(velocity_data + 2*4+1) = msg->twist.twist.linear.y;
}

float myNorm(float dx, float dy)
{
	return sqrt(dx*dx + dy*dy);
}

float sigmaNorm(float dx, float dy)
{
	return (sqrt(1 + epsilon * myNorm(dx,dy) * myNorm(dx,dy)) - 1) / epsilon;
}

float sigma_1Norm(float z)
{
	return (z / sqrt(1 + z*z));
}

float rouHFunc(float z)
{
	if ((z>=0) && (z<h))
		return 1;
	else if ((z>=h) && (z<1))
		return (0.5 * (1 + cos(PI * (z - h) / (1 - h))));
	else 
		return 0; 
}

float phi(float z)
{
    float c = (a - b) / sqrt(4 * a * b);
    float phi_val = 0.5 * ((a + b) * sigma_1Norm(z + c) + (a - b));
	return phi_val;
}
float phiAlpha(float z)
{
	float rAlpha = sigmaNorm(r,0);
	float dAlpha = sigmaNorm(d,0);
	return (rouHFunc(z / rAlpha) * phi(z - dAlpha));
}



void MA_controller()
{
	int i = 0;
	float pos_i_X = *(position_data + 2*i);
	float pos_i_Y = *(position_data + 2*i+1);	
	float vel_i_X = *(velocity_data + 2*i);
	float vel_i_Y = *(velocity_data + 2*i+1);

	if (1)
	{
		float Fi_formation_X = 0;
		float Fi_formation_Y = 0;
		float Fi_flock_X = 0;
		float Fi_flock_Y = 0;
		
		float pos_goal_X = goal_X;
		float pos_goal_Y = goal_Y;	
		float vel_goal_X = 0;
		float vel_goal_Y = 0;

//char filepath[100] ;//= "/home/exbot/catkin_ws_relay/src/turtlebot_stage/src/debug/state.txt";
//sprintf(filepath, "/home/exbot/catkin_ws_relay/src/turtlebot_stage/src/debug/state%d.txt", uID);
//FILE *pFile=fopen(filepath,"a");
		
		for(int j = 0; j < Num_Agent; j++)
		{
			float pos_j_X = *(position_data + 2*j);
			float pos_j_Y = *(position_data + 2*j+1);
			float vel_j_X = *(velocity_data + 2*j);
			float vel_j_Y = *(velocity_data + 2*j+1);

			float dist_ij = myNorm(pos_i_X - pos_j_X, pos_i_Y - pos_j_Y);


			if (dist_ij < senseRange) //distance less than a threshold, j is neighbor of i
			{
				float n_ij_X = (pos_j_X - pos_i_X) / sqrt(1 + epsilon * dist_ij * dist_ij);
				float n_ij_Y = (pos_j_Y - pos_i_Y) / sqrt(1 + epsilon * dist_ij * dist_ij);
				
				float sigmaDist_ij = sigmaNorm(pos_i_X - pos_j_X, pos_i_Y - pos_j_Y);
				Fi_formation_X = Fi_formation_X + phiAlpha(sigmaDist_ij) * n_ij_X;
				Fi_formation_Y = Fi_formation_Y + phiAlpha(sigmaDist_ij) * n_ij_Y;

//fprintf(pFile, "j:%d ", j);
				
				float rAlpha = sigmaNorm(r,0);
				float a_ij = rouHFunc(sigmaDist_ij / rAlpha);
				Fi_flock_X = Fi_flock_X + a_ij * (vel_j_X - vel_i_X);
				Fi_flock_Y = Fi_flock_Y + a_ij * (vel_j_Y - vel_i_Y);
			}
		}
		
		float Fi_goal_X = - c1 * (pos_i_X - pos_goal_X) - c2 * (vel_i_X - vel_goal_X);
		float Fi_goal_Y = - c1 * (pos_i_Y - pos_goal_Y) - c2 * (vel_i_Y - vel_goal_Y);
		
		float acc_X = Fi_formation_X/10  + Fi_flock_X + Fi_goal_X;
		float acc_Y = Fi_formation_Y/10  + Fi_flock_Y + Fi_goal_Y;

//fprintf(pFile, "\nfx:%f fy:%f\n", acc_X,acc_Y);
//fclose(pFile);		
		float accNorm = myNorm(acc_X, acc_Y);
		if (accNorm > 3) 
		{
			acc_X = acc_X / accNorm;
			acc_Y = acc_Y / accNorm;
		}

		


		float vel_X = vel_i_X + acc_X * delta_T;
		float vel_Y = vel_i_Y + acc_Y * delta_T;
		
		float velNorm = myNorm(vel_X, vel_Y);
		if (velNorm > 1) 
		{
			vel_X = vel_X / velNorm;
			vel_Y = vel_Y / velNorm;
		}
		cmd_vel.linear.x = 0.5*vel_X;
		cmd_vel.linear.y = 0.5*vel_Y;	
	}
}



int main(int argc, char **argv)
{
    ros::init(argc, argv, "leader");

    ros::NodeHandle n_;

	ros::NodeHandle n_private("~");
	n_private.param("uID", uID, 0);
	goal_X = 12;
	goal_Y = 5;

	position_data = (float *)malloc(sizeof(float) * Num_Agent * 2);	
	for (int i = 0; i < Num_Agent; i++)
	{
		*(position_data + 2*i) = 0;	
		*(position_data + 2*i + 1) = 0;			
	}
	
	velocity_data = (float *)malloc(sizeof(float) * Num_Agent * 2);	
	for (int i = 0; i < Num_Agent; i++)
	{
		*(velocity_data + 2*i) = 0;	
		*(velocity_data + 2*i + 1) = 0;			
	}

    vel_pub_ = n_.advertise<geometry_msgs::Twist>("/robot/cmd_vel", 5);
	state_sub_ = n_.subscribe("ground_truth_state", 10, stateCb);

    wayPoint_sub_ = n_.subscribe("way_point", 10, wayPointCb);

    nb1State_sub_ = n_.subscribe("nb1_ground_truth_state", 10, nb1StateCb);
	nb2State_sub_ = n_.subscribe("nb2_ground_truth_state", 10, nb2StateCb);
	nb3State_sub_ = n_.subscribe("nb3_ground_truth_state", 10, nb3StateCb);
	nb4State_sub_ = n_.subscribe("nb4_ground_truth_state", 10, nb4StateCb);

	sleep(5);
    ros::Rate loop_rate(10);
    while(ros::ok())
    {
		ros::spinOnce(); 

		MA_controller();
		vel_pub_.publish(cmd_vel);
        loop_rate.sleep();
    }

    return 0;
}
