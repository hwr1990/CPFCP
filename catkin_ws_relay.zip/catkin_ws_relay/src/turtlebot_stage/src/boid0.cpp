#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"

#include "geometry_msgs/Vector3.h"
#include "nav_msgs/Odometry.h"
#include "math.h"

ros::Publisher vel_pub;
ros::Subscriber scan_sub;

ros::Subscriber pos_sub_0;
ros::Subscriber pos_sub_1;
ros::Subscriber pos_sub_2;

/*
struct robot
{
    unsigned int id;
    float x;
    float y;
};
robot r0,r1,r2;
r0.id = 0;
r1.id = 1;
r2.id = 2;
*/

#define numRobots 3
#define numRules 5
#define myid 0
#define SENSOR_RANGE 30
#define PI 3.1415926
#define wall_width 1.5
#define region_size 10
#define obs_width 1.5
#define wall_tooclose 1.0
#define obs_tooclose 1.0
#define neighbor_tooclose 1.0

//int myid;
float pos[numRobots][2];
float last_pos[numRobots][2];
float orientation[numRobots][2];
double ori_angle[numRobots];
unsigned int neighbor[numRobots];
unsigned int numNeighbor = 0;
float obs_loc[2];

void pos0subCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	last_pos[0][0] = pos[0][0];
	last_pos[0][1] = pos[0][1];
    pos[0][0] = msg->pose.pose.position.x;
    pos[0][1] = msg->pose.pose.position.y;    
}

void pos1subCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	last_pos[1][0] = pos[1][0];
	last_pos[1][1] = pos[1][1];
    pos[1][0] = msg->pose.pose.position.x;
    pos[1][1] = msg->pose.pose.position.y;    
}

void pos2subCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	last_pos[2][0] = pos[2][0];
	last_pos[2][1] = pos[2][1];
    pos[2][0] = msg->pose.pose.position.x;
    pos[2][1] = msg->pose.pose.position.y;    
}

float dist(float x0, float y0, float x1, float y1)
{
	return sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0));
}

void sensor_neighbor()
{
    unsigned int i;
    numNeighbor = 0;
    for(i=0; i<numRobots; i++)
    {
		if ((dist(pos[myid][0], pos[myid][1], pos[i][0], pos[i][1]) < SENSOR_RANGE) && (i != myid))
		    {
				neighbor[numNeighbor++] =  i;
		    }

    }
}

int sgn(float x)
{
	return x < 0 ? 0 : 1;
}

void controller()
{
	double w[numRules];
	w[0] = 1;
	w[1] = 1.5;
	w[2] = 1;

	obs_loc[0] = 5.0;
	obs_loc[1] = 5.0;

	orientation[myid][0] = pos[myid][0] - last_pos[myid][0];
	orientation[myid][1] = pos[myid][1] - last_pos[myid][1];
	ori_angle[myid] = atan2(orientation[myid][1], orientation[myid][0]);

    unsigned int i;
	double ori_sum[2], pos_sum[2], rep_sum[2];

    ori_sum[0] = 0.0;
	ori_sum[1] = 0.0;

    pos_sum[0] = 0.0;
	pos_sum[1] = 0.0;

	rep_sum[0] = 0.0;
	rep_sum[1] = 0.0;

	double wall[2], obstacle[2];
	wall[0] = 0.0;
	wall[1] = 0.0;
	obstacle[0] = 0.0;
	obstacle[1] = 0.0;

float dist_neighbor;
bool tooclose = 0;
	for(i=0; i<numNeighbor; i++)
	{
		unsigned int neighbor_id = neighbor[i];
		orientation[neighbor_id][0] = pos[neighbor_id][0] - last_pos[neighbor_id][0];
		orientation[neighbor_id][1] = pos[neighbor_id][1] - last_pos[neighbor_id][1];


		//ori_angle[neighbor_id] = atan2(orientation[neighbor_id][1], orientation[neighbor_id][0]);

     	ori_sum[0] += orientation[neighbor_id][0];
     	ori_sum[1] += orientation[neighbor_id][1];

		pos_sum[0] += pos[neighbor_id][0];
		pos_sum[1] += pos[neighbor_id][1];

	
		dist_neighbor = dist(pos[myid][0], pos[myid][1], pos[neighbor_id][0], pos[neighbor_id][1]);
		if (dist_neighbor < neighbor_tooclose) tooclose |= 1;
		rep_sum[0] += (pos[myid][0] - pos[neighbor_id][0]) / (dist_neighbor*dist_neighbor*dist_neighbor); 
		rep_sum[1] += (pos[myid][1] - pos[neighbor_id][1]) / (dist_neighbor*dist_neighbor*dist_neighbor);

	}
    double alignment[2];
	alignment[0] = ori_sum[0]/numNeighbor;
	alignment[1] = ori_sum[1]/numNeighbor;
	double dist_align = dist(0,0,alignment[0],alignment[1]);
	if (dist_align == 0)
	{
		alignment[0] = 0.0;
		alignment[1] = 0.0;
	} 
	else
	{
		alignment[0] = alignment[0]/dist_align;
		alignment[1] = alignment[1]/dist_align;
	}

    double cohesion[2];
	cohesion[0] = pos_sum[0]/numNeighbor - pos[myid][0];
	cohesion[1] = pos_sum[1]/numNeighbor - pos[myid][1];
	double dist_coh = dist(0,0,cohesion[0],cohesion[1]);
	if (dist_coh == 0)
	{
		cohesion[0] = 0.0;
		cohesion[1] = 0.0;
	}
	else
	{
		cohesion[0] = cohesion[0]/dist_coh;
		cohesion[1] = cohesion[1]/dist_coh;
	}

	double separation[2];
	separation[0] = rep_sum[0];
	separation[1] = rep_sum[1];
	double dist_sep = dist(0,0,separation[0],separation[1]);
	if (dist_sep == 0)
	{
		separation[0] = 0.0;
		separation[1] = 0.0;
	}
	else
	{
		separation[0] = separation[0]/dist_sep;
		separation[1] = separation[1]/dist_sep;
	}


	if (tooclose) w[2] = 10;
	else w[2] = 1.0;

	double left_wall = sgn(wall_width -  pos[myid][0]) / (pos[myid][0]*pos[myid][0]*pos[myid][0]);
	double right_wall = sgn(wall_width +  pos[myid][0] - region_size) / ((region_size - pos[myid][0])*(region_size - pos[myid][0])*(region_size - pos[myid][0]));
	double down_wall = sgn(wall_width -  pos[myid][1]) / (pos[myid][1]*pos[myid][1]*pos[myid][1]);
	double up_wall = sgn(wall_width +  pos[myid][1] - region_size) / ((region_size - pos[myid][1])*(region_size - pos[myid][1])*(region_size - pos[myid][1]));
	wall[0] = left_wall - right_wall;
	wall[1] = down_wall - up_wall;
	double dist_wall = dist(0, 0, wall[0], wall[1]);
	double wall_rep[2];
	if (dist_wall == 0)
	{
		wall_rep[0] = 0.0;
		wall_rep[1] = 0.0;
	}
	else
	{
		wall_rep[0] = wall[0]/dist_wall;
		wall_rep[1] = wall[1]/dist_wall;
	}
	if ((pos[myid][0] < wall_tooclose) || (pos[myid][0] > (region_size - wall_tooclose)) || (pos[myid][1] < wall_tooclose) || (pos[myid][1] > (region_size - wall_tooclose))) w[3] = 10;
	else w[3] = 1;

	double obstacle_rep[2];
	obstacle_rep[0] = pos[myid][0] - obs_loc[0];
	obstacle_rep[1] = pos[myid][1] - obs_loc[1];
	double dist_obs = dist(0, 0, obstacle_rep[0], obstacle_rep[1]);
	obstacle_rep[0] = obstacle_rep[0]/dist_obs;
	obstacle_rep[1] = obstacle_rep[1]/dist_obs;
	if (dist(pos[myid][0], pos[myid][1], obs_loc[0], obs_loc[1]) < obs_tooclose) w[4] = 10;
	else w[4] = sgn(obs_width - dist(pos[myid][0], pos[myid][1], obs_loc[0], obs_loc[1]));

    double ori_desire[2];
	ori_desire[0] = (w[0] * alignment[0] + w[1] * cohesion[0] + w[2] * separation[0] + w[3] * wall_rep[0] + w[4] * obstacle_rep[0]) / (w[0] + w[1] + w[2] + w[3] + w[4]);
	ori_desire[1] = (w[0] * alignment[1] + w[1] * cohesion[1] + w[2] * separation[1] + w[3] * wall_rep[1] + w[4] * obstacle_rep[1]) / (w[0] + w[1] + w[2] + w[3] + w[4]);

	double turn_rate = (atan2(ori_desire[1], ori_desire[0]) - ori_angle[myid]); 
	if (turn_rate > 0 && turn_rate < PI) turn_rate = turn_rate / PI * 2;
	else if (turn_rate > -2*PI && turn_rate < -PI) turn_rate = (turn_rate + 2*PI) / PI * 2;
	else if (turn_rate > -PI && turn_rate < 0) turn_rate = turn_rate / PI * 2;
	else if (turn_rate > PI && turn_rate < 2*PI) turn_rate = (turn_rate - 2*PI) / PI * 2;
	else if (turn_rate == PI || turn_rate == -PI) turn_rate = 2;
	else turn_rate = 0;

	geometry_msgs::Twist cmd_vel;
    cmd_vel.linear.x = 0.2;
    cmd_vel.angular.z = turn_rate;

	FILE *pFile=fopen("/home/exbot/catkin_ws/src/turtlebot_simulator-indigo/turtlebot_stage/src/boid0.txt","a");
	fprintf(pFile, "%f %f %f %f %f\n", alignment[0], cohesion[0], separation[0], wall_rep[0], obstacle_rep[0]);
//    fprintf(pFile, "%f %f %f %f %f %f left:%d right:%d down:%d up:%d neighbor:%d %f %f \n", turn_rate, atan2(ori_desire[1], ori_desire[0])*180/PI, ori_angle[myid]*180/PI, w[2], w[3], w[4], sgn(wall_width -  pos[myid][0]), sgn(wall_width +  pos[myid][0] - region_size), sgn(wall_width -  pos[myid][1]), sgn(wall_width +  pos[myid][1] - region_size), tooclose, pos[myid][0], pos[myid][1]);
    fclose(pFile); 

    ROS_INFO("Angular = %f\n", cmd_vel.angular.z);
    vel_pub.publish(cmd_vel);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "boid");

    ros::NodeHandle n;

	//if (!n.getParam("myid", myid)) myid = 0;

    vel_pub = n.advertise<geometry_msgs::Twist>("/robot/cmd_vel", 5);

    //scan_sub = n.subscribe("/robot_0/base_scan", 5, laserCallback);
    pos_sub_0 = n.subscribe("robot_0/base_pose_ground_truth", 1000, pos0subCallback);
    pos_sub_1 = n.subscribe("robot_1/base_pose_ground_truth", 1000, pos1subCallback);
    pos_sub_2 = n.subscribe("robot_2/base_pose_ground_truth", 1000, pos2subCallback);
 sleep(5);
	while(ros::ok())
	{
    	ros::spinOnce();
   		sensor_neighbor();
    	controller();
	}

    return 0;
}
