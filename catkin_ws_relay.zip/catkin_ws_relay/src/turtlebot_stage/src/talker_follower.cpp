#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include "math.h"
#include "stdio.h"
//#include <turtlebot_stage/leaderPosition.h>

ros::Publisher pos_pub;

int main(int argc, char **argv)
{
    ros::init(argc, argv, "path-leader");
/*
    ros::NodeHandle n;

    ros::Rate loop_rate(10);

    pos_pub = n.advertise<turtlebot_stage::leaderPosition>("leaderPosition", 5);

	while (ros::ok())
	{
		turtlebot_stage::leaderPosition msg;

		ROS_INFO("%f %f\n", msg.x, msg.y);

		pos_pub.publish(msg);

		ros::spinOnce();

		loop_rate.sleep();
	}*/

    return 0;
}
