#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Vector3.h"
#include "nav_msgs/Odometry.h"
#include "math.h"

//#include <sstream>
float PI = 3.1415926;
float vel = 0;
float angle = 0;
float currx = 0.0;
float curry = 0.0;
float destx = 0.0;
float desty = 0.0;

float r1_x = 0.0;
float r1_y = 0.0;
float r0_x = 0.0;
float r0_y = 0.0;
int timestep = 0;
float bearing_robot = 0.0;

void chatterCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	currx = msg->pose.pose.position.x;
	curry = msg->pose.pose.position.y;	
}

void r1_Callback(const nav_msgs::Odometry::ConstPtr& msg)
{
	r1_x = msg->pose.pose.position.x;
	r1_y = msg->pose.pose.position.y;
}

void r0_Callback(const nav_msgs::Odometry::ConstPtr& msg)
{
	r0_x = msg->pose.pose.position.x;
	r0_y = msg->pose.pose.position.y;
}
void my_Controller()
{
	destx = (r1_x + r0_x)/2;
	desty = (r1_y + r0_y)/2;
//	destx = 9.6;
//	desty = 3;

	if ((currx < 0.5) || (currx > 9.5) || (curry < 0.5) || (curry > 9.5)) {destx = 5.0; desty = 5.0;}
	ROS_INFO("dest:[%lf, %lf]", destx, desty);

	if (timestep == 0)
	{
		bearing_robot = 0.0;
	}

	//float theta_robot = atan(delta_y_curr / delta_x_curr);

	float dy_in_robot_cord = cos(bearing_robot) * (desty - curry) - sin(bearing_robot) * (destx - currx);
	float dx_in_robot_cord = cos(bearing_robot) * (destx - currx) + sin(bearing_robot) * (desty - curry);

	if  (dx_in_robot_cord == 0 && dy_in_robot_cord > 0) angle = PI/2; //left

	else if  (dx_in_robot_cord == 0 && dy_in_robot_cord < 0) angle = -PI/2; //right

	else if (dx_in_robot_cord > 0) // in front side of robot 
		angle = atan(dy_in_robot_cord / dx_in_robot_cord) ;

	else if (dx_in_robot_cord < 0 && dy_in_robot_cord >= 0) // back or back-left of robot
		angle = atan(dy_in_robot_cord / dx_in_robot_cord) + PI ;

	else if (dx_in_robot_cord < 0 && dy_in_robot_cord < 0) // back-right of robot
		angle = atan(dy_in_robot_cord / dx_in_robot_cord) + PI ;

	else {angle = 0.0; ROS_INFO("ERROR [%f, %f]",dx_in_robot_cord, dy_in_robot_cord);}
	
	ROS_INFO("angle to turn:%f", 180*angle/PI);	
}



int main(int argc, char **argv)
{
	ros::init(argc, argv, "talker_stg");
	ros::NodeHandle n;
	ros::Publisher chatter_pub = n.advertise<geometry_msgs::Twist>("robot_2/cmd_vel", 1000);

	ros::Subscriber robot_2_sub = n.subscribe("robot_2/base_pose_ground_truth", 1000, chatterCallback);
	ros::Subscriber robot_1_sub = n.subscribe("robot_1/base_pose_ground_truth", 1000, r1_Callback);
	ros::Subscriber robot_0_sub = n.subscribe("robot_0/base_pose_ground_truth", 1000, r0_Callback);

	
	sleep(10); // wait for that all nodes initial done

	ros::Rate loop_rate(10);
	ros::Rate loop_out(10);

	//ROS_INFO("angle:%f", angle);
	while(ros::ok())
	{
		geometry_msgs::Twist msg;
		geometry_msgs::Vector3 linear_value, angular_value;

		linear_value.x = 0.0;
		linear_value.y = 0.0;
		linear_value.z = 0.0;
		
		angular_value.x = 0.0;
		angular_value.y = 0.0;
		angular_value.z = 0.0;


		ros::spinOnce(); // subscribe
		my_Controller();

		int count = 0;
		while (ros::ok())
		{
			linear_value.x = 0.0;

			if (angle == 0) angular_value.z = 0.0;
			else angular_value.z = angle > 0 ? 0.1 : -0.1;

			msg.linear = linear_value;
			msg.angular = angular_value;

			chatter_pub.publish(msg);
			
			++count;			
			ROS_INFO("count:%d",count);
			if (fabs(angular_value.z) * 0.1 * count >= fabs(angle))
				break;
			loop_rate.sleep();
		}
		bearing_robot += angular_value.z * 0.1 * count;
		if (bearing_robot > PI) bearing_robot = bearing_robot - 2*PI;
		else if (bearing_robot < (-PI)) bearing_robot = bearing_robot + 2*PI;
		else bearing_robot = bearing_robot;

		ROS_INFO("angle turned:%f, bearing now:%f", (fabs(angular_value.z) * 0.1 * count)*180/PI, bearing_robot*180/PI);

		linear_value.x = 0.2;
		angular_value.z = 0.0;

		msg.linear = linear_value;
		msg.angular = angular_value;
		chatter_pub.publish(msg);

		timestep++;

		loop_out.sleep();

	}
	
	return 0;
}
